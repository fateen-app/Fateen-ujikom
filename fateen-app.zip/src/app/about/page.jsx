
"use client"
const PageAbout =  ()=>{

    return(
        <div className="flex flex-wrap items-center justify-evenly bg-amber-500 h-screen hover:bg-blue-600  transition-all duration-1000"> 
                    <div className=" hover:scale-110 delay-300 flex justify-center items-center w-42 h-42 p-8  bg-red-600/80 text-white  text-2xl font-bold  rounded-tr-3xl rounded-bl-3xl shadow-2xs shadow-black ">
              kotak 1
            </div>
                    <div className=" hover:animate-bounce flex justify-center items-center w-42 h-42 p-8  bg-red-600/80 text-white  text-2xl font-bold  rounded-tr-3xl rounded-bl-3xl shadow-2xs shadow-black ">
              kotak 1
            </div>  
            <div className=" hover:animate-spin  flex justify-center items-center w-42 h-42 p-8  bg-red-600/80 text-white  text-2xl font-bold  rounded-tr-3xl rounded-bl-3xl shadow-2xs shadow-black ">
              kotak 1
            </div>
              <div className=" hover:animate-spin  flex justify-center items-center w-42 h-42 p-8  bg-red-600/80 text-white  text-2xl font-bold  rounded-tr-3xl rounded-bl-3xl shadow-2xs shadow-black ">
              kotak 1
            </div>
              <div className=" hover:animate-spin  flex justify-center items-center w-42 h-42 p-8  bg-red-600/80 text-white  text-2xl font-bold  rounded-tr-3xl rounded-bl-3xl shadow-2xs shadow-black ">
              kotak 1
            </div>
              <div className=" hover:animate-spin  flex justify-center items-center w-42 h-42 p-8  bg-red-600/80 text-white  text-2xl font-bold  rounded-tr-3xl rounded-bl-3xl shadow-2xs shadow-black ">
              kotak 1
            </div>
            
        </div>
        
    )
}
export default PageAbout