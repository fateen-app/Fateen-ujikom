
"use client"
const fateenWeb =  ()=>{

    return(
        <div>
          <h1 className="flex justify-between px-1.5 py-1.5  bg-blue-700 ">
            fateen</h1>
        <h2>
            kelas=XII</h2>
     
        </div>
    )
}
export default fateenWeb