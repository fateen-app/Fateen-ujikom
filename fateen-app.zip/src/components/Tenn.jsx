"use client"

import Header from "@/components/header"

 const Tenn =(props)=>{
    return(
        
        <Header ngaranWeb="mobile legend"/>

    )

 }  
 export default Tenn 